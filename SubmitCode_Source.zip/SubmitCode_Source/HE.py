from PIL import Image, ImageOps
import numpy as np
import time



def histogram_equalization_rgb(image_path):
    # 读取原始RGB图像
    original_image = Image.open(image_path)

    # 将RGB图像转化为灰度图像
    gray_image = ImageOps.grayscale(original_image)

    # 将灰度图像转换为numpy数组
    gray_array = np.asarray(gray_image)

    # 进行直方图均衡化
    histogram, bins = np.histogram(gray_array.flatten(), 256, density=True)
    cdf = histogram.cumsum()
    cdf_normalized = cdf * histogram.max() / cdf.max()

    # 使用线性插值的方式计算新的像素值
    cdf_m = np.ma.masked_equal(cdf, 0)
    cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min())
    cdf = np.ma.filled(cdf_m, 0).astype('uint8')

    equalized_gray_array = cdf[gray_array]

    # Above is done by ChatGPT


    # 计算比值
    ratio = equalized_gray_array.astype(np.float32) / gray_array.astype(np.float32)

    # 将比值乘到原RGB图像上
    original_array = np.asarray(original_image).astype(np.float32)
    equalized_rgb_array = original_array * ratio[:, :, np.newaxis]

    # 将结果转化为图像格式并保存
    Image.fromarray(np.clip(equalized_rgb_array, 0, 255).astype('uint8')).show()


image_path = './Original_Image/moon.jpeg'
# image_path = './Original_Image/bulb.jpeg'
# image_path = './Original_Image/bridge.jpeg'
# image_path = './Original_Image/sea_shore.jpg'
# image_path = './Original_Image/temple.png'
# start = time.time()
histogram_equalization_rgb(image_path)
# end = time.time()
# print(f'Running time: {end - start} s')