import numpy as np
from PIL import Image

# This is done by ChatGPT
def gamma_correction(image, gamma):
    inv_gamma = 1.0 / gamma
    table = [((i / 255.0) ** inv_gamma) * 255 for i in range(256)]
    table = np.array(table, dtype='uint8')
    return image.point(lambda x: table[x])


# start = time.time()
# Load the input image
# input_image_path = './Original_Image/moon.jpeg'
# input_image_path = './Original_Image/bridge.jpeg'
# input_image_path = './Original_Image/sea_shore.jpg'
# input_image_path = './Original_Image/temple.png'
input_image_path = './Original_Image/bulb.jpeg'
image = Image.open(input_image_path)

# Apply gamma correction
gamma = 2.8
GC = gamma_correction(image, gamma)
GC.show()
# end = time.time()
# print(f'Running time: {end - start} s')


