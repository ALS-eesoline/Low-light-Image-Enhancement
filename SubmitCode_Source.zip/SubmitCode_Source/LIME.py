import numpy as np
from scipy.fftpack import fft2, ifft2
from scipy.signal import convolve2d
from PIL import Image
import matplotlib.pyplot as plt




# calculate the horizontal gradient of the image
def gradient_h(img):
    kernel = np.array([[1, -1]])
    return convolve2d(img, kernel, mode='same', boundary='wrap')

# calculate the transpose of the horizontal gradient of the image
def gradient_h_T(img):
    kernel = np.array([[-1, 1]])
    return convolve2d(img, kernel, mode='same', boundary='wrap')

# calculate the vertical gradient of the image
def gradient_v(img):
    kernel = np.array([[1], [-1]])
    return convolve2d(img, kernel, mode='same', boundary='wrap')


# calculate the transpose of the vertical gradient of the image
def gradient_v_T(img):
    kernel = np.array([[-1], [1]])
    return convolve2d(img, kernel, mode='same', boundary='wrap')


# shrinkage operator
def shrinkage_operator(x, kappa):
    return np.sign(x) * np.maximum(np.abs(x) - kappa, 0)

# load Image
# input_image_path = './Original_Image/moon.jpeg'
# input_image_path = './Original_Image/bridge.jpeg'
input_image_path = './Original_Image/bulb.jpeg'
# input_image_path = './Original_Image/sea_shore./jpg'
# input_image_path = './Original_Image/temple.png'

image = Image.open(input_image_path).convert('RGB')
image = np.array(image).astype(np.float64)

image = image / 255.0

M, N, channel = image.shape

# Initial illumination map
T_hat = np.max(image, axis=2)

# initial T, G, Z
T = np.ones((M, N))
G = np.ones((2, M, N))
Z = np.ones((2, M, N))

u = 1
alpha = 500
rho = 30.1 # The greater rho is, the faster the convergence is

# Compute W matrices
Wv = 1 / (0.01 + np.abs(gradient_v(T_hat)))
Wh = 1 / (0.01 + np.abs(gradient_h(T_hat)))
# Wv = 10  # constant W is also OK
# Wh = 10

# maximum number of iterations and the convergence criterion
max_iterations = 12
epsilon = 0.01


# used to plot the convergence curve
cost1 = []
cost2 = []

# the gradient kernel (D_h) used fot FFT
kernel_h = np.zeros((M, N))
kernel_h[0, 0] = 1
kernel_h[0, 1] = -1
FDh = fft2(kernel_h)

# the gradient kernel (D_v) used fot FFT
kernel_v = np.zeros((M, N))
kernel_v[0, 0] = 1
kernel_v[1, 0] = -1
FDv = fft2(kernel_v)


# These type of kernel is also OK
# the gradient kernel (D_h^T D_h) used fot FFT
# kernel_h = np.zeros((M, N))
# kernel_h[0, 0] = -1
# kernel_h[0, 1] = 2
# kernel_h[0, 2] = -1
# FDh_DD = fft2(kernel_h)

# the gradient kernel (D_v^T D_v) used fot FFT
# kernel_v = np.zeros((M, N))
# kernel_v[0, 0] = -1
# kernel_v[1, 0] = 2
# kernel_v[2, 0] = -1
# FDv_DD = fft2(kernel_v)


for t in range(max_iterations):
    print(f'Iteration {t + 1}/{max_iterations}')

    # Update T
    RHS = 2 * T_hat.flatten() + u * (gradient_h_T(G[0] - Z[0] / u).flatten() + gradient_v_T(G[1] - Z[1] / u).flatten())
    RHS = RHS.reshape(M, N)

    # numerator
    Frhs = fft2(RHS)

    # denominator
    den = 2 + u * (np.abs(FDh) ** 2 + np.abs(FDv) ** 2)
    # den = 2 + u * (np.abs(FDh_DD) + np.abs(FDv_DD))  # This is also OK,
    T = np.abs(ifft2(Frhs / den))

    # Update G
    grad_T_h = gradient_h(T)
    grad_T_v = gradient_v(T)
    G[0] = shrinkage_operator(grad_T_h + Z[0] / u,  Wh / u)
    G[1] = shrinkage_operator(grad_T_v + Z[1] / u,  Wv / u)

    # Update Z and u
    Z[0] += u * (grad_T_h - G[0])
    Z[1] += u * (grad_T_v - G[1])
    u *= rho

    # Calculate the convergence criterion
    norm_diff_h = np.sum((grad_T_h - G[0])**2)**0.5 / np.sum(T_hat**2)**0.5
    norm_diff_v = np.sum((grad_T_v - G[1])**2)**0.5 / np.sum(T_hat**2)**0.5


    cost1.append((np.linalg.norm(T_hat - T))**2)
    cost2.append(alpha*(np.linalg.norm(Wv * grad_T_v,ord=1)) + alpha*(np.linalg.norm(Wh * grad_T_h, ord=1)))
    print(f"norm_diff_h = {norm_diff_h}, norm_diff_v = {norm_diff_v}")

    #Check for convergence
    if norm_diff_h <= epsilon and norm_diff_v <= epsilon:
        break

# Gamma correction
T = T**0.5

# Display the illumination map
plt.figure()
plt.imshow(T, cmap='gray')
plt.title('Illumination Map')
plt.axis('off')
plt.show()

# Show the convergence curve
# plt.figure()
# plt.plot(np.array(cost2)+np.array(cost1), label='Cost')
# plt.xlabel('Iteration')
# plt.ylabel('Cost Value')
# plt.legend()
# plt.show()

image = image * 255
Trgb = np.repeat(T[:, :, np.newaxis], 3, axis=2)

# enhance the image
refined_img = image / (Trgb+0.00001)

# clip the pixel values to [0, 255]
refined_img = np.clip(refined_img, 0, 255)

refined_img_8bit = (refined_img).astype(np.uint8)
Image.fromarray(refined_img_8bit).show()




