Original_Image： 原始图片（low-light）

EnhancedByLIME: LIME 算法 提亮的结果

EnhancedByHE： 直方图均衡 提亮的结果

EnhancedByGC：伽马矫正 提亮的结果

LIME.py：LIME算法实现

HE.py：直方图均衡算法实现

GC.py：伽马矫正算法实现


.py代码均可一键运行，代码内有详细注释，需要安装的库：numpy, PIL, scipy, matplotlib